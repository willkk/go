#! /bin/bash

echo "start app"


